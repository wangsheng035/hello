package com.xuecheng.test.rabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Administrator
 * @version 1.0
 * @create 2018-06-17 20:46
 **/
@SpringBootApplication
public class TestRabbitmqApplication {
    public static void main(String[] args) {
        SpringApplication.run(TestRabbitmqApplication.class,args);
    }
}
